package com.xj.test;

public class jsonText {
	public static void main(String[] args) {
		System.out.println("烟煤".length());
		System.out.println("1".length());
	}
}
