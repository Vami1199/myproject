package com.xj.service.base;

import java.util.List;

import com.xj.domain.base.BCoaltype;
import com.xj.domain.base.BCoaltypeQuery;

public interface BCoalTypeService {

	List<BCoaltype> findAll(BCoaltypeQuery coaltypeQuery);

}
