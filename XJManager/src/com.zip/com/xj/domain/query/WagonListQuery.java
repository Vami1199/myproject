package com.xj.domain.query;

import com.xj.domain.base.BRailwaywagon;

public class WagonListQuery {
	private BRailwaywagon wagon;

	public BRailwaywagon getWagon() {
		return wagon;
	}

	public void setWagon(BRailwaywagon wagon) {
		this.wagon = wagon;
	}
	
}
