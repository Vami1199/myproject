package com.xj.domain.query.base;

import com.xj.domain.base.BRailwaywagonsys;

public class WagonsysListQuery {
	private BRailwaywagonsys wagonsys;

	public BRailwaywagonsys getWagonsys() {
		return wagonsys;
	}

	public void setWagonsys(BRailwaywagonsys wagonsys) {
		this.wagonsys = wagonsys;
	}
	
}
