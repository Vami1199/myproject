package com.xj.domain.base;

import java.io.Serializable;
import java.util.Date;

public class BCoalassay implements Serializable {
    private String caId;

    private String caName;

    /**
     * 单位
     */
    private String caUnit;

    /**
     * 简称
     */
    private String caEn;

    /**
     * 创建日期
     */
    private Date createdate;

    /**
     * 修改日期
     */
    private Date modifydate;

    /**
     * 创建人
     */
    private String createby;

    /**
     * 修改人
     */
    private String modifyby;

    private String caRemark;

    private static final long serialVersionUID = 1L;

    public String getCaId() {
        return caId;
    }

    public void setCaId(String caId) {
        this.caId = caId == null ? null : caId.trim();
    }

    public String getCaName() {
        return caName;
    }

    public void setCaName(String caName) {
        this.caName = caName == null ? null : caName.trim();
    }

    public String getCaUnit() {
        return caUnit;
    }

    public void setCaUnit(String caUnit) {
        this.caUnit = caUnit == null ? null : caUnit.trim();
    }

    public String getCaEn() {
        return caEn;
    }

    public void setCaEn(String caEn) {
        this.caEn = caEn == null ? null : caEn.trim();
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby == null ? null : createby.trim();
    }

    public String getModifyby() {
        return modifyby;
    }

    public void setModifyby(String modifyby) {
        this.modifyby = modifyby == null ? null : modifyby.trim();
    }

    public String getCaRemark() {
        return caRemark;
    }

    public void setCaRemark(String caRemark) {
        this.caRemark = caRemark == null ? null : caRemark.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", caId=").append(caId);
        sb.append(", caName=").append(caName);
        sb.append(", caUnit=").append(caUnit);
        sb.append(", caEn=").append(caEn);
        sb.append(", createdate=").append(createdate);
        sb.append(", modifydate=").append(modifydate);
        sb.append(", createby=").append(createby);
        sb.append(", modifyby=").append(modifyby);
        sb.append(", caRemark=").append(caRemark);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}