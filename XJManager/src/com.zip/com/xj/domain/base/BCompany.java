package com.xj.domain.base;

import java.io.Serializable;
import java.util.Date;

public class BCompany implements Serializable {
    private String coId;
    
    private String coShort;

    private String coName;

    private String coPhone;

    private Integer coPostcode;

    private String coFax;

    private String coLeader;

    private String coAddress;

    private String coLinkman;
   

    /**
     * 创建日期
     */
    private Date createdate;

    /**
     * 修改日期
     */
    private Date modifydate;

    /**
     * 创建人
     */
    private String createby;

    /**
     * 修改人
     */
    private String modifyby;

    private static final long serialVersionUID = 1L;

    public String getCoId() {
        return coId;
    }

    public void setCoId(String coId) {
        this.coId = coId == null ? null : coId.trim();
    }

    public String getCoShort() {
        return coShort;
    }

    public void setCoShort(String coShort) {
        this.coShort = coShort == null ? null : coShort.trim();
    }

    public String getCoName() {
        return coName;
    }

    public void setCoName(String coName) {
        this.coName = coName == null ? null : coName.trim();
    }

    public String getCoPhone() {
        return coPhone;
    }

    public void setCoPhone(String coPhone) {
        this.coPhone = coPhone == null ? null : coPhone.trim();
    }

    public Integer getCoPostcode() {
        return coPostcode;
    }

    public void setCoPostcode(Integer coPostcode) {
        this.coPostcode = coPostcode;
    }

    public String getCoFax() {
        return coFax;
    }

    public void setCoFax(String coFax) {
        this.coFax = coFax == null ? null : coFax.trim();
    }

    public String getCoLeader() {
        return coLeader;
    }

    public void setCoLeader(String coLeader) {
        this.coLeader = coLeader == null ? null : coLeader.trim();
    }

    public String getCoAddress() {
        return coAddress;
    }

    public void setCoAddress(String coAddress) {
        this.coAddress = coAddress == null ? null : coAddress.trim();
    }

    public String getCoLinkman() {
        return coLinkman;
    }

    public void setCoLinkman(String coLinkman) {
        this.coLinkman = coLinkman == null ? null : coLinkman.trim();
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby == null ? null : createby.trim();
    }

    public String getModifyby() {
        return modifyby;
    }

    public void setModifyby(String modifyby) {
        this.modifyby = modifyby == null ? null : modifyby.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", coId=").append(coId);
        sb.append(", coShort=").append(coShort);
        sb.append(", coName=").append(coName);
        sb.append(", coPhone=").append(coPhone);
        sb.append(", coPostcode=").append(coPostcode);
        sb.append(", coFax=").append(coFax);
        sb.append(", coLeader=").append(coLeader);
        sb.append(", coAddress=").append(coAddress);
        sb.append(", coLinkman=").append(coLinkman);
        sb.append(", createdate=").append(createdate);
        sb.append(", modifydate=").append(modifydate);
        sb.append(", createby=").append(createby);
        sb.append(", modifyby=").append(modifyby);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}