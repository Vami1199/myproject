package com.xj.domain.trainsplan;

import java.io.Serializable;
import java.util.Date;

public class PDayrequest implements Serializable {
    private String dId;

    private Date dDate;

    private String dUser;

    private String dAuditor;

    private String dStart;

    /**
     * 请车数
     */
    private Integer dTrainnumber;

    /**
     * 确认数
     */
    private Integer dRnumber;

    /**
     * 实发车数
     */
    private Integer dRealtrain;

    /**
     * 运输量
     */
    private Long dWeight;

    /**
     * 状态
     */
    private Byte dState;

    /**
     * 创建日期
     */
    private Date createdate;

    /**
     * 修改日期
     */
    private Date modifydate;

    /**
     * 创建人
     */
    private String createby;

    /**
     * 修改人
     */
    private String modifyby;

    private String dRemark;

    private static final long serialVersionUID = 1L;

    public String getdId() {
        return dId;
    }

    public void setdId(String dId) {
        this.dId = dId == null ? null : dId.trim();
    }

    public Date getdDate() {
        return dDate;
    }

    public void setdDate(Date dDate) {
        this.dDate = dDate;
    }

    public String getdUser() {
        return dUser;
    }

    public void setdUser(String dUser) {
        this.dUser = dUser == null ? null : dUser.trim();
    }

    public String getdAuditor() {
        return dAuditor;
    }

    public void setdAuditor(String dAuditor) {
        this.dAuditor = dAuditor == null ? null : dAuditor.trim();
    }

    public String getdStart() {
        return dStart;
    }

    public void setdStart(String dStart) {
        this.dStart = dStart == null ? null : dStart.trim();
    }

    public Integer getdTrainnumber() {
        return dTrainnumber;
    }

    public void setdTrainnumber(Integer dTrainnumber) {
        this.dTrainnumber = dTrainnumber;
    }

    public Integer getdRnumber() {
        return dRnumber;
    }

    public void setdRnumber(Integer dRnumber) {
        this.dRnumber = dRnumber;
    }

    public Integer getdRealtrain() {
        return dRealtrain;
    }

    public void setdRealtrain(Integer dRealtrain) {
        this.dRealtrain = dRealtrain;
    }

    public Long getdWeight() {
        return dWeight;
    }

    public void setdWeight(Long dWeight) {
        this.dWeight = dWeight;
    }

    public Byte getdState() {
        return dState;
    }

    public void setdState(Byte dState) {
        this.dState = dState;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby == null ? null : createby.trim();
    }

    public String getModifyby() {
        return modifyby;
    }

    public void setModifyby(String modifyby) {
        this.modifyby = modifyby == null ? null : modifyby.trim();
    }

    public String getdRemark() {
        return dRemark;
    }

    public void setdRemark(String dRemark) {
        this.dRemark = dRemark == null ? null : dRemark.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", dId=").append(dId);
        sb.append(", dDate=").append(dDate);
        sb.append(", dUser=").append(dUser);
        sb.append(", dAuditor=").append(dAuditor);
        sb.append(", dStart=").append(dStart);
        sb.append(", dTrainnumber=").append(dTrainnumber);
        sb.append(", dRnumber=").append(dRnumber);
        sb.append(", dRealtrain=").append(dRealtrain);
        sb.append(", dWeight=").append(dWeight);
        sb.append(", dState=").append(dState);
        sb.append(", createdate=").append(createdate);
        sb.append(", modifydate=").append(modifydate);
        sb.append(", createby=").append(createby);
        sb.append(", modifyby=").append(modifyby);
        sb.append(", dRemark=").append(dRemark);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}