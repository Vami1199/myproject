package com.xj.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;

import com.xj.domain.trainsplan.PAddwithoutcontract;
import com.xj.domain.trainsplan.PAddwithoutcontractQuery;

public interface PAddwithoutcontractDao {
    int countByExample(PAddwithoutcontractQuery example);

    int deleteByExample(PAddwithoutcontractQuery example);

    int deleteByPrimaryKey(String awtId);

    int insert(PAddwithoutcontract record);

    int insertSelective(PAddwithoutcontract record);

    List<PAddwithoutcontract> selectByExampleWithBLOBs(PAddwithoutcontractQuery example);

    List<PAddwithoutcontract> selectByExample(PAddwithoutcontractQuery example);

    PAddwithoutcontract selectByPrimaryKey(String awtId);

    int updateByExampleSelective(@Param("record") PAddwithoutcontract record, @Param("example") PAddwithoutcontractQuery example);

    int updateByExampleWithBLOBs(@Param("record") PAddwithoutcontract record, @Param("example") PAddwithoutcontractQuery example);

    int updateByExample(@Param("record") PAddwithoutcontract record, @Param("example") PAddwithoutcontractQuery example);

    int updateByPrimaryKeySelective(PAddwithoutcontract record);

    int updateByPrimaryKeyWithBLOBs(PAddwithoutcontract record);

    int updateByPrimaryKey(PAddwithoutcontract record);
}